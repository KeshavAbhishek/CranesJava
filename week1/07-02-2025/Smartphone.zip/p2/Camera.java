package p2;

public interface Camera {
    void takePhoto();
    void recordVideo(int duration);
}