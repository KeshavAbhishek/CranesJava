package p1;

public interface Phone {
    void makeCall(String phoneNumber);
    void sendMessage(String phoneNumber, String message);
}