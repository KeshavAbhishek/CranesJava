import p1.Phone;
import p2.Camera;

public class Smartphone implements Phone, Camera {

    @Override
    public void makeCall(String phoneNumber) {
        System.out.println("Calling " + phoneNumber + "...");
    }

    @Override
    public void sendMessage(String phoneNumber, String message) {
        System.out.println("Sending message to " + phoneNumber + ": " + message);
    }

    @Override
    public void takePhoto() {
        System.out.println("Taking a photo...");
    }

    @Override
    public void recordVideo(int duration) {
        System.out.println("Recording video for " + duration + " seconds...");
    }

    public static void main(String[] args) {
        Smartphone smartphone = new Smartphone();
        
        smartphone.makeCall("123-456-7890");
        smartphone.sendMessage("123-456-7890", "Hello, this is a test message.");
        smartphone.takePhoto();
        smartphone.recordVideo(10);
    }
}